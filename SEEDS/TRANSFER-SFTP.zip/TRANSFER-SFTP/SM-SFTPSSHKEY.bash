aws secretsmanager create-secret --name user1-ssh-key --secret-string "ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEA..."
